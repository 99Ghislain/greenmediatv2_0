@extends('layouts/guestLayout')
@section('layoutContent')
{{--  --}}
<div class="container" style="margin-top: -30px; margin-bottom: 30px !important;">
    <div class="banner">
        <figure class="ads text-center">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5336231094781905" crossorigin="anonymous"></script>
            <!-- annonce 1 header av stream -->
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="ca-pub-5336231094781905"
                 data-ad-slot="7358428411"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            <script>
                 (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </figure>
    </div>
</div>
{{--  --}}
<section class="gm-news-section">
    <div class="container">

       <div class="" style="margin-bottom: 30px;"> 
            <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow"> 
        &nbsp; <span class="gm-animated-dot"></span> A LA UNE &nbsp;
            </div>
        </div>
      
        @php
            if(isset($hcarous) && count($hcarous) > 0) {
                $hcarous = $hcarous->where('slug_prinrub', '!=', 'english article')->values();
            }
        @endphp

        @if(isset($hcarous) && count($hcarous) > 0)
            <div class="row">
                
                <div class="col-md-7 mb-4">
                    
<div class="gm-main-card">
        <a href="{{route('visitors.sgactu',['rub'=>$hcarous[0]->slug_prinrub,'slug'=>$hcarous[0]->slug_article,'ip'=>$hcarous[0]->id_article])}}" class="gm-main-img-wrap">
            <img src="{{url('hphx/img/'.$hcarous[0]->image_article)}}" alt="{{$hcarous[0]->title_article}}">
        </a>
    
        <div class="gm-main-content">
            <div class="d-flex align-items-center flex-wrap">
            <a href="{{route('visitors.allactus',['rub' => $hcarous[0]->slug_prinrub])}}" class="gm-badge">
                {{$hcarous[0]->desig_prinrub}}
            </a>
            <span class="gm-separator">|</span>
            <span style="font-weight: 500; text-transform: none;"><strong style="font-size: 1rem">
                @if(!empty($hcarous[0]->datepub_article))
                    {{ \Carbon\Carbon::parse($hcarous[0]->datepub_article)->locale('fr')->diffForHumans() }}
                @else
                    {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                @endif
            </strong></span>
            <span class="gm-separator">|</span>
            <span>
                <i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hcarous[0]->view_article}}</strong>
            </span>
            <span class="gm-separator">|</span>
            <span>
                <strong style="font-size: 1.3rem">TEMPS DE LECTURE: {{ $hcarous[0]->temps_lecture ?? 1 }} min</strong>
            </span>

        </div>

        <a href="{{route('visitors.sgactu',['rub'=>$hcarous[0]->slug_prinrub,'slug'=>$hcarous[0]->slug_article,'ip'=>$hcarous[0]->id_article])}}" class="gm-main-title">
            <span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hcarous[0]->title_article), 120)}}</span>
        </a>
                    <p class="gm-main-desc">
            {{Str::limit($hcarous[0]->desc_article, 170)}}
                    </p>
            </div>
    </div>
                </div>
                <hr>

                <div class="col-md-5">
                    @php
                        if(isset($hrandarts) && count($hrandarts) > 0) {
                            $hrandarts = $hrandarts->where('slug_prinrub', '!=', 'english article')->values();
                        }
                    @endphp

                    @if(isset($hrandarts)&&count($hrandarts)!=0)
                        @foreach($hrandarts as $hrh)
                            
                            <div class="gm-side-card">
                                <a href="{{route('visitors.sgactu',['rub'=>$hrh->slug_prinrub,'slug'=>$hrh->slug_article,'ip'=>$hrh->id_article])}}" class="gm-side-body">
                                    <img src="{{url('hphx/img/'.$hrh->image_article)}}" alt="{{$hrh->title_article}}" class="gm-side-img">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hrh->title_article), 80)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hrh->desc_article, 80)}}</p>
                                    </div>
                                </a>
                                
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hrh->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hrh->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hrh->datepub_article))
                                            {{ \Carbon\Carbon::parse($hrh->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                   </strong> </span>
                                    <span class="gm-separator">|</span>
                                    <span>
                                        <i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hrh->view_article}}</strong>
                                    </span>
                                    <span class="gm-separator">|</span>
                                    <span>
                                        <strong style="font-size: 1rem"> Temps de lecture: {{ $hrh->temps_lecture ?? 1 }} min</strong>
                                    </span>
                                </div>
                            </div>

                        @endforeach
                    @endif
                </div>
            </div>
        @endif

        <hr>

        <div class="mt-4 mb-4"></div>

      <div class="" style="margin-bottom: 30px;"> 
                <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow"> 
        &nbsp; <span class="gm-animated-dot"></span> ARTICLES RECENTS &nbsp;
                    </div>
       </div>

        <div class="row" style="display: flex; flex-wrap: wrap;">
    @php
        if(isset($hcf) && count($hcf) > 0) {
            $hcf = $hcf->where('slug_prinrub', '!=', 'english article')->values();
        }
    @endphp

    @if(isset($hcf)&&count($hcf)!=0)
        @foreach ($hcf as $is)
            <div class="col-md-3 gm-grid-col" style="margin-bottom: 30px;">
                
                <div class="gm-grid-card" style="width: 100%;">
                    <a href="{{route('visitors.sgactu',['rub'=>$is->slug_prinrub,'slug'=>$is->slug_article,'ip'=>$is->id_article])}}">
                        <img src="{{url('hphx/img/'.$is->image_article)}}" alt="{{$is->title_article}}" class="gm-grid-img">
                    </a>
                    
                    <div class="gm-grid-body">
                        <a href="{{route('visitors.sgactu',['rub'=>$is->slug_prinrub,'slug'=>$is->slug_article,'ip'=>$is->id_article])}}" class="gm-grid-title">
                            <h3 class="gm-grid-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($is->title_article), 90)}}</span></h3>
                        </a>
                        <p class="gm-side-desc">
                            {{Str::limit($is->desc_article, 100)}}
                        </p>
                    </div>

                    <div class="gm-card-footer">
                        <a href="{{route('visitors.allactus',['rub' => $is->slug_prinrub])}}" style="font-weight: 700;">
                            {{$is->desig_prinrub}}
                        </a>
                        <span class="gm-separator" style="margin: 0 5px;">|</span>
                        <span style="text-transform: none;"><strong style="font-size: 1rem">
                            @if(!empty($is->datepub_article))
                                {{ \Carbon\Carbon::parse($is->datepub_article)->locale('fr')->diffForHumans() }}
                            @else
                                {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                            @endif
                        </strong></span>
                        <span class="gm-separator" style="margin: 0 5px;">|</span>
                        <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$is->view_article}}</strong></span>
                        <span class="gm-separator" style="margin: 0 5px;">|</span>
                        <span><strong style="font-size: 1rem">TEMPS DE LECTURE: {{ $is->temps_lecture ?? 1 }} min </strong></span>
                    </div>
                </div>
            </div>
        @endforeach
    @endif
    
             <div class="col-12 mt-3 mb-5" style="display: flex; justify-content: center; width: 100%;">
                <a href="{{route('visitors.allactus',['rub' => $hcarous[0]->slug_prinrub])}}" class="btn btn-outline-success" style="border-radius: 30px; font-weight: 700; padding: 12px 35px; border-color: #127319; color: #127319;"> 
        Voir plus d'actualités <i class="ion-ios-arrow-thin-right"></i>
                </a>
            </div>
        </div>
    </div>
</section>
{{--  --}}

<section class="container" style="margin-top: -15px;">
    <div class="banner">
        <figure class="ads text-center">
            @if(isset($pubs_i2)&&count($pubs_i2)!=0)
            <a href="<?=(isset($pubs_i2[0])&&!empty($pubs_i2[0]))?$pubs_i1[0]->linkdest_pub:false;?>" style="display: block;" target="_blank">
                <img src="{{url('hphx/img/'.$pubs_i2[0]->image_pub)}}" class="dpub-under-" style="width: 100%;">
            </a>
            @endif
        </figure>
    </div>
</section>


<section class="home" style="margin-top: 20px; padding: 0;">
    <div class="container">
        
        <div class="" style="margin-bottom: 30px;"> 
            <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow"> 
                &nbsp; <span class="gm-animated-dot"></span> AGRICULTURES &nbsp;<a href="{{route('visitors.allactus',['rub' => 'agriculture'])}}" class="btn btn-success b-radius-6" style="padding: 1px auto; font-weight: 200%;"><i class="ion-ios-arrow-thin-right"></i></a>&nbsp; 
            </div>
        </div>

        @if(isset($hagriart) && !empty($hagriart))
            
            <div class="row">
                
                <div class="col-md-7" style="margin-bottom: 30px;">
                    
                    <div class="gm-main-card">
                        <a href="{{route('visitors.sgactu',['rub'=>$hagriart[0]->slug_prinrub,'slug'=>$hagriart[0]->slug_article,'ip'=>$hagriart[0]->id_article])}}" class="gm-main-img-wrap">
                            <img src="{{url('hphx/img/'.$hagriart[0]->image_article)}}" alt="{{$hagriart[0]->title_article}}">
                        </a>
                        
                        <div class="gm-main-content">
                            <div style="display: flex; align-items: center; flex-wrap: wrap;">
                                <a href="{{route('visitors.allactus',['rub' => $hagriart[0]->slug_prinrub])}}" class="gm-badge">
                                    {{$hagriart[0]->desig_prinrub}}
                                </a>
                                <span class="gm-separator">|</span>
                                <span style="font-weight: 500; text-transform: none;"><strong style="font-size: 1rem">
                                    @if(!empty($hagriart[0]->datepub_article))
                                        {{ \Carbon\Carbon::parse($hagriart[0]->datepub_article)->locale('fr')->diffForHumans() }}
                                    @else
                                        {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                    @endif
                                </strong></span>
                                <span class="gm-separator">|</span>
                                <span><strong style="font-size: 1.1rem">TEMPS DE LECTURE: {{ $hagriart[0]->temps_lecture ?? 1 }} min</strong></span>
                            </div>

                            <a href="{{route('visitors.sgactu',['rub'=>$hagriart[0]->slug_prinrub,'slug'=>$hagriart[0]->slug_article,'ip'=>$hagriart[0]->id_article])}}" class="gm-main-title">
                                <span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hagriart[0]->title_article), 120)}}</span>
                            </a>
                            <p class="gm-main-desc">
                                {{Str::limit($hagriart[0]->desc_article, 170)}}
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-5">
                    @for($i=1; $i<=3; $i++)
                        @if(isset($hagriart[$i]))
                            <div class="gm-side-card" style="margin-bottom: 25px;">
                                <a href="{{route('visitors.sgactu',['rub'=>$hagriart[$i]->slug_prinrub,'slug'=>$hagriart[$i]->slug_article,'ip'=>$hagriart[$i]->id_article])}}" class="gm-side-body">
                                    <img src="{{url('hphx/img/'.$hagriart[$i]->image_article)}}" alt="{{$hagriart[$i]->title_article}}" class="gm-side-img">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hagriart[$i]->title_article), 80)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hagriart[$i]->desc_article, 80)}}</p>
                                    </div>
                                </a>
                                
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hagriart[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hagriart[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hagriart[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hagriart[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                    </strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hagriart[$i]->view_article}}</strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><strong style="font-size: 1rem">TEMPS DE LECTURE: {{ $hagriart[$i]->temps_lecture ?? 1 }} min</strong></span>
                                </div>
                            </div>
                        @endif
                    @endfor
                </div>
            </div>

            <div class="row" style="margin-top: 15px;">
                @for($i=4; $i<=7; $i++)
                    @if(isset($hagriart[$i]))
                        <div class="col-md-6" style="margin-bottom: 30px;">
                            <div class="gm-side-card" style="height: 100%; margin-bottom: 0;">
                                <a href="{{route('visitors.sgactu',['rub'=>$hagriart[$i]->slug_prinrub,'slug'=>$hagriart[$i]->slug_article,'ip'=>$hagriart[$i]->id_article])}}" class="gm-side-body" style="flex-grow: 1;">
                                    <img src="{{url('hphx/img/'.$hagriart[$i]->image_article)}}" alt="{{$hagriart[$i]->title_article}}" class="gm-side-img" style="width: 160px; height: 120px;">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hagriart[$i]->title_article), 90)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hagriart[$i]->desc_article, 90)}}</p>
                                    </div>
                                </a>
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hagriart[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hagriart[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hagriart[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hagriart[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                    </strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hagriart[$i]->view_article}}</strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><strong style="font-size: 1rem">TEMPS DE LECTURE: {{ $hagriart[$i]->temps_lecture ?? 1 }} min</strong></span>
                                </div>
                            </div>
                        </div>
                    @endif
                @endfor
            </div>

            <div class="row" style="margin-top: 15px;">
                @for($i=8; $i<=11; $i++) 
                    @if(isset($hagriart[$i]))
                        <div class="col-md-3 gm-grid-col" style="margin-bottom: 40px;">
                            <div class="gm-grid-card">
                                <a href="{{route('visitors.sgactu',['rub'=>$hagriart[$i]->slug_prinrub,'slug'=>$hagriart[$i]->slug_article,'ip'=>$hagriart[$i]->id_article])}}">
                                    <img src="{{url('hphx/img/'.$hagriart[$i]->image_article)}}" alt="{{$hagriart[$i]->title_article}}" class="gm-grid-img">
                                </a>
                                <div class="gm-grid-body">
                                    <a href="{{route('visitors.sgactu',['rub'=>$hagriart[$i]->slug_prinrub,'slug'=>$hagriart[$i]->slug_article,'ip'=>$hagriart[$i]->id_article])}}" class="gm-grid-title">
                                       <h3 class="gm-side-title"> <span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hagriart[$i]->title_article), 90)}}</span></h3>
                                    </a>
                                    <p class="gm-side-desc">
                                        {{Str::limit($hagriart[$i]->desc_article, 100)}}
                                    </p>
                                </div>
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hagriart[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hagriart[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator" style="margin: 0 5px;">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hagriart[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hagriart[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                    </strong></span>
                                    <span class="gm-separator" style="margin: 0 5px;">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hagriart[$i]->view_article}}</strong></span>
                                    <span class="gm-separator" style="margin: 0 5px;">|</span>
                                    <span> <strong style="font-size: 1rem">Temps de lecture : {{$hagriart[$i]->temps_lecture ?? 1}} min</strong></span>
                                    
                                </div>
                            </div>
                        </div>
                    @endif
                @endfor
            </div>

        @endif
        
        <div class="row">
            <div class="col-12 text-center" style="margin-top: 10px; margin-bottom: 50px;">
                <a href="{{route('visitors.allactus',['rub' => 'agriculture'])}}" class="btn btn-outline-success" style="border-radius: 30px; font-weight: 700; padding: 12px 35px; border-color: #127319; color: #127319;"> 
                    Voir + d'actualités <i class="ion-ios-arrow-thin-right"></i>
                </a>
            </div>
        </div>
        
    </div>
</section>


<section class="container">
    <div class="banner" style="">
        <figure class="ads text-center">
            @if(isset($pubs_i3)&&count($pubs_i3)!=0)
                <a href="<?=(isset($pubs_i3[0])&&!empty($pubs_i3[0]))?$pubs_i3[0]->linkdest_pub:false;?>" style="display: block;" target="_blank">
                    <img src="{{url('hphx/img/'.$pubs_i3[0]->image_pub)}}" class="dpub-under-" style="width: 100%;">
                </a>
            @endif
        </figure>
    </div>
</section>



<section style="margin-top: 20px; padding: 0;">
    <div class="container">
        
        <div class="" style="margin-bottom: 30px;"> 
            <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow"> 
                &nbsp; <span class="gm-animated-dot"></span> + D'ARTICLES POPULAIRES &nbsp;
            </div>
        </div>

        <div class="row mt-4" style="display: flex; flex-wrap: wrap;">
            @if(isset($pplars) && count($pplars) != 0)
                @foreach($pplars as $hrh)
                    
                    <div class="col-md-4 gm-grid-col" style="margin-bottom: 40px;">
                        
                        <div class="gm-grid-card" style="width: 100%;">
                            <a href="{{route('visitors.sgactu',['rub'=>$hrh->slug_prinrub,'slug'=>$hrh->slug_article,'ip'=>$hrh->id_article])}}">
                                <img src="{{url('hphx/img/'.$hrh->image_article)}}" alt="{{$hrh->title_article}}" class="gm-grid-img">
                            </a>
                            
                            <div class="gm-grid-body">
                                <a href="{{route('visitors.sgactu',['rub'=>$hrh->slug_prinrub,'slug'=>$hrh->slug_article,'ip'=>$hrh->id_article])}}" class="gm-grid-title">
                                  <h3 class="gm-side-title">  <span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hrh->title_article), 90)}}</span></h3>
                                </a>
                                <p class="gm-side-desc">
                                    {{Str::limit($hrh->desc_article, 100)}}
                                </p>
                            </div>

                            <div class="gm-card-footer">
                                <a href="{{route('visitors.allactus',['rub' => $hrh->slug_prinrub])}}" style="font-weight: 700;">
                                    {{$hrh->desig_prinrub}}
                                </a>
                                <span class="gm-separator" style="margin: 0 5px;">|</span>
                                <span style="text-transform: none;"><strong style="font-size: 1rem">
                                    @if(!empty($hrh->datepub_article))
                                        {{ \Carbon\Carbon::parse($hrh->datepub_article)->locale('fr')->diffForHumans() }}
                                    @else
                                        {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                    @endif
                               </strong> </span>
                                <span class="gm-separator" style="margin: 0 5px;">|</span>
                                <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hrh->view_article}}</strong></span>
                                <span class="gm-separator" style="margin: 0 5px;">|</span>
                                <span> <strong style="font-size: 1rem">Temps de lecture : {{$hrh->temps_lecture ?? 1}} min</strong></span>
                            </div>
                        </div>
                    </div>

                @endforeach
            @endif
        </div>

    </div>
</section>



<div class="container" style="">
    <div class="banner">
        <figure class="ads text-center">
            @if(isset($pubs_i4)&&count($pubs_i4)!=0)
            <a href="<?=(isset($pubs_i4[0])&&!empty($pubs_i4[0]))?$pubs_i4[0]->linkdest_pub:false;?>" style="display: block;" target="_blank">
                <img src="{{url('hphx/img/'.$pubs_i4[0]->image_pub)}}" class="dpub-under-" style="">
            </a>
            @endif
        </figure>
    </div>  
</div>



<section class="home" style="margin-top: 20px; padding: 0;">
    <div class="container">
        
        <div class="" style="margin-bottom: 30px;">
            <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow">
                &nbsp; <span class="gm-animated-dot"></span> ENVIRONNEMENT &nbsp;
                <a href="{{route('visitors.allactus',['rub' => 'environnement'])}}" class="btn btn-success b-radius-6" style="padding: 1px auto; font-weight: 200%;">
                    <i class="ion-ios-arrow-thin-right"></i>
                </a>&nbsp;
            </div>
        </div>

        @if(isset($hallsoarts) && !empty($hallsoarts))
            
            <div class="row">
                
                <div class="col-md-7" style="margin-bottom: 30px;">
                    
                    <div class="gm-main-card">
                        <a href="{{route('visitors.sgactu',['rub'=>$hallsoarts[0]->slug_prinrub,'slug'=>$hallsoarts[0]->slug_article,'ip'=>$hallsoarts[0]->id_article])}}" class="gm-main-img-wrap">
                            <img src="{{url('hphx/img/'.$hallsoarts[0]->image_article)}}" alt="{{$hallsoarts[0]->title_article}}">
                        </a>
                        
                        <div class="gm-main-content">
                            <div style="display: flex; align-items: center; flex-wrap: wrap;">
                                <a href="{{route('visitors.allactus',['rub' => $hallsoarts[0]->slug_prinrub])}}" class="gm-badge">
                                    {{$hallsoarts[0]->desig_prinrub}}
                                </a>
                                <span class="gm-separator">|</span>
                                <span style="font-weight: 500; text-transform: none;"><strong style="font-size: 1rem">
                                    @if(!empty($hallsoarts[0]->datepub_article))
                                        {{ \Carbon\Carbon::parse($hallsoarts[0]->datepub_article)->locale('fr')->diffForHumans() }}
                                    @else
                                        {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                    @endif
                                </strong></span>
                                <span class="gm-separator">|</span>
                                <span> <strong style="font-size: 1rem">Temps de lecture: {{ $hallsoarts[0]->temps_lecture ?? 1 }} min </strong></span>
                            </div>

                            <a href="{{route('visitors.sgactu',['rub'=>$hallsoarts[0]->slug_prinrub,'slug'=>$hallsoarts[0]->slug_article,'ip'=>$hallsoarts[0]->id_article])}}" class="gm-main-title">
                                <span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hallsoarts[0]->title_article), 120)}}</span>
                            </a>
                            <p class="gm-main-desc">
                                {{Str::limit($hallsoarts[0]->desc_article, 170)}}
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-5">
                    @for($i=1; $i<=3; $i++)
                        @if(isset($hallsoarts[$i]))
                            <div class="gm-side-card" style="margin-bottom: 25px;">
                                <a href="{{route('visitors.sgactu',['rub'=>$hallsoarts[$i]->slug_prinrub,'slug'=>$hallsoarts[$i]->slug_article,'ip'=>$hallsoarts[$i]->id_article])}}" class="gm-side-body">
                                    <img src="{{url('hphx/img/'.$hallsoarts[$i]->image_article)}}" alt="{{$hallsoarts[$i]->title_article}}" class="gm-side-img">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hallsoarts[$i]->title_article), 80)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hallsoarts[$i]->desc_article, 80)}}</p>
                                    </div>
                                </a>
                                
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hallsoarts[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hallsoarts[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hallsoarts[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hallsoarts[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                    </strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hallsoarts[$i]->view_article}}</strong></span>
                                    <span class="gm-separator">|</span>
                                    <span> <strong style="font-size: 1rem">Temps de lecture: {{ $hallsoarts[$i]->temps_lecture ?? 1 }} min </strong></span>
                                </div>
                            </div>
                        @endif
                    @endfor
                </div>
            </div>

            <div class="row" style="margin-top: 15px;">
                @for($i=4; $i<=7; $i++)
                    @if(isset($hallsoarts[$i]))
                        <div class="col-md-6" style="margin-bottom: 30px;">
                            <div class="gm-side-card" style="height: 100%; margin-bottom: 0;">
                                <a href="{{route('visitors.sgactu',['rub'=>$hallsoarts[$i]->slug_prinrub,'slug'=>$hallsoarts[$i]->slug_article,'ip'=>$hallsoarts[$i]->id_article])}}" class="gm-side-body" style="flex-grow: 1;">
                                    <img src="{{url('hphx/img/'.$hallsoarts[$i]->image_article)}}" alt="{{$hallsoarts[$i]->title_article}}" class="gm-side-img" style="width: 160px; height: 120px;">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hallsoarts[$i]->title_article), 90)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hallsoarts[$i]->desc_article, 90)}}</p>
                                    </div>
                                </a>
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hallsoarts[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hallsoarts[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hallsoarts[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hallsoarts[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                      </strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hallsoarts[$i]->view_article}}</strong></span>
                                    <span class="gm-separator">|</span>
                                    <span> <strong style="font-size: 1rem">Temps de lecture: {{ $hallsoarts[$i]->temps_lecture ?? 1 }} min</strong></span>
                                </div>
                            </div>
                        </div>
                    @endif
                @endfor
            </div>

        @endif
        
        <div class="row">
            <div class="col-12 text-center" style="margin-top: 10px; margin-bottom: 50px;">
                <a href="{{route('visitors.allactus',['rub' => 'environnement'])}}" class="btn btn-outline-success" style="border-radius: 30px; font-weight: 700; padding: 12px 35px; border-color: #127319; color: #127319;"> 
                    Voir plus d'actualités <i class="ion-ios-arrow-thin-right"></i>
                </a>
            </div>
        </div>
        
    </div>
</section>



<div class="container" style="">
    <div class="banner">
        <figure class="ads text-center">
            @if(isset($pubs_i5)&&count($pubs_i5)!=0)
            <a href="<?=(isset($pubs_i5[0])&&!empty($pubs_i5[0]))?$pubs_i5[0]->linkdest_pub:false;?>" style="display: block;" target="_blank">
                <img src="{{url('hphx/img/'.$pubs_i5[0]->image_pub)}}" class="dpub-under-" style="">
            </a>
            @endif
        </figure>
    </div>
</div>



<section class="home" style="margin-top: 20px; margin-bottom: 50px; padding: 0;">
    <div class="container">
        
        <div class="" style="margin-bottom: 30px;">
            <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow">
                &nbsp; <span class="gm-animated-dot"></span> RESS ANIMALES &nbsp;
                <a href="{{route('visitors.allactus',['rub' => 'ressourcesanimales'])}}" class="btn btn-success b-radius-6" style="padding: 1px auto; font-weight: 200%;">
                    <i class="ion-ios-arrow-thin-right"></i>
                </a>&nbsp;
            </div>
        </div>

        @if(isset($hallspoarts) && !empty($hallspoarts))
            
            <div class="row">
                
                <div class="col-md-7" style="margin-bottom: 30px;">
                    
                    <div class="gm-main-card">
                        <a href="{{route('visitors.sgactu',['rub'=>$hallspoarts[0]->slug_prinrub,'slug'=>$hallspoarts[0]->slug_article,'ip'=>$hallspoarts[0]->id_article])}}" class="gm-main-img-wrap">
                            <img src="{{url('hphx/img/'.$hallspoarts[0]->image_article)}}" alt="{{$hallspoarts[0]->title_article}}">
                        </a>
                        
                        <div class="gm-main-content">
                            <div style="display: flex; align-items: center; flex-wrap: wrap;">
                                <a href="{{route('visitors.allactus',['rub' => $hallspoarts[0]->slug_prinrub])}}" class="gm-badge">
                                    {{$hallspoarts[0]->desig_prinrub}}
                                </a>
                                <span class="gm-separator">|</span>
                                <span style="font-weight: 500; text-transform: none;"><strong style="font-size: 1rem">
                                    @if(!empty($hallspoarts[0]->datepub_article))
                                        {{ \Carbon\Carbon::parse($hallspoarts[0]->datepub_article)->locale('fr')->diffForHumans() }}
                                    @else
                                        {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                    @endif
                                </strong></span>
                                <span class="gm-separator">|</span>
                                <span> <strong style="font-size: 1rem">Temps de lecture: {{ $hallspoarts[0]->temps_lecture ?? 1 }} min</strong></span>
                            </div>

                            <a href="{{route('visitors.sgactu',['rub'=>$hallspoarts[0]->slug_prinrub,'slug'=>$hallspoarts[0]->slug_article,'ip'=>$hallspoarts[0]->id_article])}}" class="gm-main-title">
                                <span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hallspoarts[0]->title_article), 120)}}</span>
                            </a>
                            <p class="gm-main-desc">
                                {{Str::limit($hallspoarts[0]->desc_article, 170)}}
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-5">
                    @for($i=1; $i<=3; $i++)
                        @if(isset($hallspoarts[$i]) && ($hallspoarts[$i] != null))
                            <div class="gm-side-card" style="margin-bottom: 25px;">
                                <a href="{{route('visitors.sgactu',['rub'=>$hallspoarts[$i]->slug_prinrub,'slug'=>$hallspoarts[$i]->slug_article,'ip'=>$hallspoarts[$i]->id_article])}}" class="gm-side-body">
                                    <img src="{{url('hphx/img/'.$hallspoarts[$i]->image_article)}}" alt="{{$hallspoarts[$i]->title_article}}" class="gm-side-img">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hallspoarts[$i]->title_article), 80)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hallspoarts[$i]->desc_article, 80)}}</p>
                                    </div>
                                </a>
                                
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hallspoarts[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hallspoarts[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hallspoarts[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hallspoarts[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                    </strong> </span>
                                    <span class="gm-separator">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hallspoarts[$i]->view_article}}</strong></span>
                                    <span class="gm-separator">|</span>
                                    <span> <strong style="font-size: 1rem">Temps de lecture: {{ $hallspoarts[$i]->temps_lecture ?? 1 }} min</strong></span>
                                </div>
                            </div>
                        @endif
                    @endfor
                </div>
            </div>

            <div class="row" style="margin-top: 15px;">
                @for($i=4; $i<=7; $i++)
                    @if(isset($hallspoarts[$i]) && ($hallspoarts[$i] != null))
                        <div class="col-md-6" style="margin-bottom: 30px;">
                            <div class="gm-side-card" style="height: 100%; margin-bottom: 0;">
                                <a href="{{route('visitors.sgactu',['rub'=>$hallspoarts[$i]->slug_prinrub,'slug'=>$hallspoarts[$i]->slug_article,'ip'=>$hallspoarts[$i]->id_article])}}" class="gm-side-body" style="flex-grow: 1;">
                                    <img src="{{url('hphx/img/'.$hallspoarts[$i]->image_article)}}" alt="{{$hallspoarts[$i]->title_article}}" class="gm-side-img" style="width: 160px; height: 120px;">
                                    <div class="gm-side-text">
                                        <h3 class="gm-side-title"><span style="font-weight: 900 !important; font-family: 'Montserrat', sans-serif;">{{Str::limit(formatTitle($hallspoarts[$i]->title_article), 90)}}</span></h3>
                                        <p class="gm-side-desc">{{Str::limit($hallspoarts[$i]->desc_article, 90)}}</p>
                                    </div>
                                </a>
                                <div class="gm-card-footer">
                                    <a href="{{route('visitors.allactus',['rub' => $hallspoarts[$i]->slug_prinrub])}}" style="font-weight: 700;">
                                        {{$hallspoarts[$i]->desig_prinrub}}
                                    </a>
                                    <span class="gm-separator">|</span>
                                    <span style="text-transform: none;"><strong style="font-size: 1rem">
                                        @if(!empty($hallspoarts[$i]->datepub_article))
                                            {{ \Carbon\Carbon::parse($hallspoarts[$i]->datepub_article)->locale('fr')->diffForHumans() }}
                                        @else
                                            {{ \Carbon\Carbon::now()->locale('fr')->diffForHumans() }}
                                        @endif
                                     </strong></span>
                                    <span class="gm-separator">|</span>
                                    <span><i class="ion-ios-eye gm-icon-eye"></i> <strong>{{$hallspoarts[$i]->view_article}}</strong></span>
                                    <span class="gm-separator">|</span>
                                    <span> <strong style="font-size: 1rem">Temps de lecture: {{ $hallspoarts[$i]->temps_lecture ?? 1 }} min</strong></span>
                                </div>
                            </div>
                        </div>
                    @endif
                @endfor
            </div>

        @endif
        
        <div class="row">
            <div class="col-12 text-center" style="margin-top: 10px; margin-bottom: 20px;">
                <a href="{{route('visitors.allactus',['rub' => 'ressourcesanimales'])}}" class="btn btn-outline-success" style="border-radius: 30px; font-weight: 700; padding: 12px 35px; border-color: #127319; color: #127319;"> 
                    Voir plus d'actualités <i class="ion-ios-arrow-thin-right"></i>
                </a>
            </div>
        </div>
        
    </div>
</section>

<!-- Modal Newsletter Pop-up -->
<div class="modal fade" id="newsletterModal" tabindex="-1" role="dialog" aria-labelledby="newsletterModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" style="border-radius: 0;">
      
      <!-- En-tête avec bouton de fermeture -->
      <div class="modal-header bg-success text-white" style="border-radius: 0;">
        <h5 class="modal-title" id="newsletterModalLabel">
          <i class="fa fa-envelope"></i> Newsletter Green Media TV
        </h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Fermer" style="background: transparent; border: 0; font-size: 1.5rem;">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <!-- Corps du Pop-up -->
      <div class="modal-body text-center p-4">
        <h4 class="mb-3">Ne manquez aucune actualité !</h4>
        <p class="text-muted mb-4">Abonnez-vous pour recevoir nos meilleurs articles et alertes infos directement dans votre boîte mail.</p>
        
        <form action="{{ route('newsletter.store') }}" method="POST">
          @csrf
          <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Votre adresse email *" required style="border-radius: 0; padding: 20px 15px;">
          </div>
          <button type="submit" class="btn btn-success btn-block" style="border-radius: 0; padding: 10px; width: 100%;">Je m'abonne</button>
        </form>
      </div>
      
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Vérifie si le pop-up a déjà été affiché durant cette session
    if (!sessionStorage.getItem('newsletter_shown')) {
        setTimeout(function() {
            $('#newsletterModal').modal('show');
        }, 2000); // Délai de 2 secondes
        
        sessionStorage.setItem('newsletter_shown', 'true');
    }
});
</script>
{{--  --}}
{{--  --}}

@endsection