{{-- Live Streaming / Vidéo à la une --}}
@php
    $mainVideo = null;
    $sortedVideos = [];

    if(isset($hlastvd) && count($hlastvd) > 0) {
        // 1. On cherche d'abord s'il y a une vidéo en "Live Streaming" (type 2)
        foreach($hlastvd as $video) {
            if(isset($video->typevideo_id) && $video->typevideo_id == '2') {
                $mainVideo = $video;
                break;
            }
        }
        
        // 2. S'il n'y a pas de Live en ce moment, on prend la vidéo la plus récente
        if($mainVideo == null) {
            $mainVideo = $hlastvd[0];
        }

        // 3. On réorganise la playlist pour le JavaScript (La vidéo principale d'abord)
        $tempMain = clone $mainVideo;
        $tempMain->formatted_title = formatTitle($mainVideo->title_video);
        $tempMain->formatted_date = phxdtformat(date_create($mainVideo->datepub_video));
        $sortedVideos[] = $tempMain;
        
        foreach($hlastvd as $vd) {
            if($vd->id_video != $mainVideo->id_video) {
                $temp = clone $vd;
                $temp->formatted_title = formatTitle($vd->title_video);
                $temp->formatted_date = phxdtformat(date_create($vd->datepub_video));
                $sortedVideos[] = $temp;
            }
        }
    }
@endphp

<section class="m-0 p-0" style="padding-bottom: 0;">
    <div class="container-fluid px-0" style="padding: 0 auto !important;">
        <div class="row">
            <div class="col-md-12 ">
                <div class="d-flex position-relative justify-content-between align-items-center breaking-news bg-white mt-2 b-radius-6" style="position: relative;">
                    <marquee class="news-scroll bg-dark b-radius-6 b-white-shadow" behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();" style="background-color: #000; line-height: 25px;" >
                        @if(isset($fhs)&&count($fhs)!=0)
                            @foreach($fhs as $f)
                            <a href="{{$f->article_flash}}" style="color: #fff;"> <span class="dot"></span> {{Str::limit($f->desig_flash,200)}}</a>
                            @endforeach
                        @endif
                    </marquee>
                    <div class="position-absolute d-flex flex-row flex-grow-1 flex-fill justify-content-center py-2 text-white px-1 news b-radius-6" style="position: absolute; background: #c00; height: 25px; line-height: 25px; top: 0;"><span class="d-flex align-items-center" style="font-weight: bolder; ">&nbsp;FLASH INFO</span></div>
                </div>
            </div>
        </div>
    </div>
</section>

@if($mainVideo != null)
<section class="home" style="margin-top: 20px ; padding: 0;">
    <div class="container-fluid px-0">
        <div class="" style="margin-bottom: 30px;"> 
            <div class="acategory-two text-color-1 top-title-2 text-uppercase b-white-shadow"> 
                &nbsp; <span class="gm-animated-dot" style="background-color: #d32f2f;"></span> 
                @if(isset($mainVideo->typevideo_id) && $mainVideo->typevideo_id == '2')
                    LIVE STREAMING
                @else
                    VIDÉO À LA UNE
                @endif
                &nbsp;
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12" style="padding-bottom: 10px; margin-bottom: 5px;">
                
                <style>
                    .video-card-modern {
                        border-radius: 12px;
                        overflow: hidden;
                        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                        background: linear-gradient(135deg, #e0ebe0 0%, #c1c4c2 100%); 
                        margin-bottom: 20px;
                    }
                    .video-info-classy {
                        padding: 22px 25px;
                    }
                    .video-meta {
                        display: flex; align-items: center; gap: 15px; margin-bottom: 12px; flex-wrap: wrap;
                    }
                    .live-badge-modern {
                        background-color: #e53935; color: #ffffff !important; padding: 6px 16px;
                        border-radius: 30px; font-size: 0.85rem; font-weight: 700; text-transform: uppercase;
                        text-decoration: none; display: flex; align-items: center; gap: 8px;
                        box-shadow: 0 4px 10px rgba(229, 57, 53, 0.4); transition: transform 0.2s ease;
                    }
                    .live-badge-modern:hover {
                        transform: translateY(-2px); color: #ffffff; text-decoration: none;
                    }
                    .live-dot {
                        width: 8px; height: 8px; background-color: #ffffff; border-radius: 50%;
                        display: inline-block; animation: pulse-live 1.5s infinite;
                    }
                    @keyframes pulse-live {
                        0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7); }
                        70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(255, 255, 255, 0); }
                        100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0); }
                    }
                    .video-date-modern {
                        color: rgba(12, 5, 5, 0.85); font-size: 0.95rem; font-weight: 500;
                    }
                    .video-title-modern {
                        color: #ffffff !important; font-size: 1.35rem; font-weight: 700; line-height: 1.4;
                        text-decoration: none; display: block; text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
                        transition: color 0.2s ease;
                    }
                    .video-title-modern:hover {
                        color: #c8e6c9 !important; text-decoration: none;
                    }
                    /* Style du bouton Activer le son (centré, gros et bien visible) */
                    .sound-overlay-btn {
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        z-index: 20;
                        background: rgba(229, 57, 53, 0.95);
                        color: #ffffff;
                        border: 2px solid #ffffff;
                        padding: 14px 28px;
                        font-size: 16px;
                        font-weight: 800;
                        text-transform: uppercase;
                        border-radius: 50px;
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        box-shadow: 0 6px 30px rgba(0,0,0,0.7);
                        transition: all 0.2s ease;
                    }
                    .sound-overlay-btn:hover {
                        background: #c62828;
                        transform: translate(-50%, -50%) scale(1.05);
                    }
                </style>

                <div class="video-card-modern">
                    <article style="position: relative; overflow: hidden; padding: 0 !important; margin: 0 auto; aspect-ratio: 16/9; background-color: #000;">
                        <div id="youtube-player" style="width:100%; height:100%;"></div>  
                        
                        <button id="unmute-btn" class="sound-overlay-btn" onclick="activateSound()">
                            <i class="ion-android-volume-up" style="font-size: 1.4rem;"></i> Activer le son
                        </button>
                    </article>

                    <div class="video-info-classy">
                        <div class="video-meta">
                            <a href="{{route('visitors.allvideos')}}" class="live-badge-modern" style="{{ $mainVideo->typevideo_id != '2' ? 'background-color: #ffa000; box-shadow: 0 4px 10px rgba(255, 160, 0, 0.4);' : '' }}">
                                @if(isset($mainVideo->typevideo_id) && $mainVideo->typevideo_id == '2')
                                    <span class="live-dot"></span> EN DIRECT
                                @else
                                    <i class="ion-ios-videocam"></i> TV
                                @endif
                            </a>
                            <span id="video-date" class="video-date-modern">
                                {{ phxdtformat(date_create($mainVideo->datepub_video)) }}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 

    <script src="https://www.youtube.com/iframe_api"></script>
    <script>
        let videos = @json($sortedVideos);
        
        let playlist = [
            @foreach($sortedVideos as $video)
                "{{ getYoutubeId($video->linkyoutube_video) }}",
            @endforeach
        ];
        
        let currentIndex = 0;
        let player;
        let soundActivated = false;

        function onYouTubeIframeAPIReady(){
            player = new YT.Player('youtube-player', {
                height: '100%', 
                width: '100%',
                videoId: playlist[0], 
                playerVars : {
                    autoplay: 1,
                    mute: 1, // Lancement automatique sans son
                    rel: 0,
                    modestbranding: 1
                },
                events : {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        function onPlayerReady(event) {
            // Plus d'activation automatique par la page. Le son ne s'active que si l'utilisateur clique sur le bouton.
        }

        // Fonction déclenchée uniquement si l'utilisateur clique sur le bouton central "Activer le son"
        function activateSound(){
            if(player && typeof player.unMute === 'function'){
                player.unMute();
                player.setVolume(100);
                soundActivated = true;
                
                let btn = document.getElementById('unmute-btn');
                if(btn) btn.style.display = 'none';
            }
        }

        function onPlayerStateChange(event){
            if(event.data == YT.PlayerState.ENDED){
                currentIndex++;
                if(currentIndex >= playlist.length){
                    currentIndex = 0;
                }
                player.loadVideoById(playlist[currentIndex]);
                document.getElementById('video-date').innerText = videos[currentIndex].formatted_date;
            }
        }
    </script>
</section>
@endif