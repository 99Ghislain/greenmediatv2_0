@extends("layouts/appLayout")
@section("layoutContent")
<div class="row">
  <div class="col-12 mb-3">
    <a href="{{ route('admins.addredacteur') ?? '#' }}" class="btn btn-info">
      <span class="d-none d-sm-inline-block">Ajouter un Rédacteur&nbsp;&nbsp;</span>
      <i class="fa fa-plus"></i>
    </a>
  </div>
  <div class="col-12">
  <h2 style="text-align: center;">Liste des Rédacteurs</h2>
    <form method="get" action="{{ route('admins.allredacteurs') }}" class="card">
      <div class="card-header">
        <h3 class="card-title">Tous les rédacteurs</h3>
        <div class="card-tools"> 
          <div class="input-group input-group-m border-radius-0" style="<?=!empty($dsrch)?'width: 100%;':'width: 100%;';?>">
            <input type="text" name="t_search" class="form-control float-right border-radius-0" value="<?=!empty($dsrch)?$dsrch:false;?>" placeholder="Rechercher par nom">
            <div class="input-group-append border-radius-0">
              <button type="submit" class="btn btn-default border-radius-0"><i class="fas fa-search"></i></button>
              <?php if (!empty($dsrch)): ;?>
              <a href="{{ route('admins.allredacteurs') }}" class="btn btn-dark border-radius-0">Voir liste  <i class="fas fa-list"></i></a>
              <?php endif ;?>
            </div>
          </div>
        </div>
      </div>
      <div class="card-body table-responsive p-0">
        <table class="table table-head-fixed table-condensed table-striped hovered text-nowrap" style="overflow: auto;">
          <thead>
            <tr>
              <th style="width: 10%;">Photo</th>
              <th style="width: 25%;">Nom</th>
              <th style="width: 45%;">Biographie</th>
              <th colspan="2" style="width: 20%; text-align: center;">Actions</th>
            </tr>
          </thead>
          <tbody>
            @if(isset($redacteurs) && count($redacteurs) > 0)
                @foreach($redacteurs as $redacteur)
                <tr>
                  <td style="width: 10%;">
                      {{-- Les images des rédacteurs sont généralement dans public/uploads/redacteurs/ --}}
                      <img src="{{ !empty($redacteur->photo_redacteur) ? asset('uploads/redacteurs/'.$redacteur->photo_redacteur) : asset('images/default-avatar.png') }}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 50%; margin: 0 auto; display: block;">
                  </td>
                  <td style="width: 25%; font-weight: bold; vertical-align: middle;" title="{{ $redacteur->nom_redacteur }}">{{ $redacteur->nom_redacteur }}</td>
                  <td style="width: 45%; vertical-align: middle; white-space: normal;">{{ Str::limit($redacteur->bio_redacteur, 90) }}</td>
                  
                  <td style="width: 10%; text-align: center; vertical-align: middle;">
                      <a href="{{ route('admins.allredacteurs', ['up' => $redacteur->id_redacteur]) }}" class="btn btn-info">
                          <span class="d-none d-sm-inline-block">Modifier&nbsp;&nbsp;</span><i class="fa fa-edit"></i>
                      </a>
                  </td>
                  <td style="width: 10%; text-align: center; vertical-align: middle;">
                      <button type="button" data-toggle="modal" data-target="#supredacteur{{ $redacteur->id_redacteur }}" class="btn btn-danger">
                          <span class="d-none d-sm-inline-block">Supprimer&nbsp;&nbsp;</span><i class="fa fa-trash"></i>
                      </button>
                  </td>
                </tr>
                @endforeach
              @else
              <tr style="width: 100%;">
                <td colspan="5" style="width: 100%; text-align: center;"><span class="alert alert-danger" >Aucun rédacteur enregistré pour le moment ... </span></td>
              </tr>
            @endif
          </tbody>
        </table>
      </div>
      @if(method_exists($redacteurs, 'links'))
        {{ $redacteurs->links('contents.apps.templates.blockpagination') }}
      @endif
      
    </form>
  </div>
</div>
@stop