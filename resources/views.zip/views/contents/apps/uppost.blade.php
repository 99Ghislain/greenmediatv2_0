@extends("layouts/appLayout")
@section("layoutContent")
<div class="row">
  <div class="col-12">
    <form method="POST" action="{{route('admins.updatepost')}}" class="card" enctype="multipart/form-data">
      @csrf   
      <div class="card-body ">
        <!-- Informations sur  -->
        <!--  -->
        <div role="form">
          <div class="row" style="margin: 10px auto 20px auto; /*text-align: center;*/ ">
            <div class="col-sm-12">
              <!-- text input--> 
              <div class="">
                <img src="{{url('hphx/img/'.$hupart[0]->image_article)}}" style="/*min-width: 300px;*/ max-height: 350px;">
              </div>
              <span>{{$hupart[0]->imgsubtitle_article}}</span>
            </div>
            <hr/>
            
          </div>
          <div class="row">
            <div class="col-sm-2 d-none">
              <!-- text input -->
              <div class="form-group">
                <label>ID </label>
                <input type="text" class="form-control border-radius-0 " name="post_id" placeholder="ID de l'article *" required="required" value="{{$hupart[0]->id_article}}">
              </div>
            </div>
            <div class="col-sm-12">
              <!-- text input -->
              <div class="form-group">
                <label>Titre </label>
                <input type="text" class="form-control border-radius-0" name="post_title" placeholder="Titre de l'article *" required="required" value="{{$hupart[0]->title_article}}">
              </div>
            </div>
            <div class="col-sm-12">
              <!-- text input -->
              <div class="form-group">
                <label>Description / Chapô </label>
                <textarea type="text" class="form-control border-radius-0" name="post_chapo" placeholder="Chapô *" rows=required="required" >{{$hupart[0]->desc_article}}</textarea>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <!-- text input --> 
              <div class="form-group">
                <label>Image à l'Une <span style="color: #f00;">[1600 x 1200 pixels maximale]</span></label>
                <input type="file" class="form-control border-radius-0" name="post_firstimg" placeholder="" >
                <input type="text" class="form-control border-radius-0 d-none" name="post_imgfirst" placeholder="image *" required="required" value="{{$hupart[0]->image_article}}">
              </div>
            </div>
            <div class="col-sm-6">
              <!-- text input -->
              <div class="form-group">
                <label>Sous-titre image </label>
                <input type="text" class="form-control border-radius-0" name="post_subtitle" placeholder="Sous-titre image *" required="required" value="{{$hupart[0]->imgsubtitle_article}}">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12">
              <!-- text input -->
              <div class="form-group">
                <label>Contenu </label>
                <textarea id="contenuarticle-" rows="15" type="textarea" class="form-control textarea border-radius-0 phxtextarea" name="post_content" style="font-family: 'Agency FB' !important;" placeholder="Ecrivez en long et en large votre contenu ... *"><?=$hupart[0]->content_article;?></textarea>
              </div>
            </div>
          </div>
          <div class="row">
    <div class="col-sm-12">
        <!-- Sélection du rédacteur -->
        <div class="form-group">
            <label for="post_redacteur">Rédacteur de l'article &nbsp;<span style="color: red">*</span>&nbsp;:</label>
            <select id="post_redacteur" class="form-control border-radius-0" name="id_redacteur" required="required">
                <option value=""><-- Choix du Rédacteur --></option>
                @foreach($hallredacteurs as $redac)
                    <option value="{{ $redac->id_redacteur }}" 
                        {{ (isset($hupart[0]->id_redacteur) && $hupart[0]->id_redacteur == $redac->id_redacteur) ? 'selected' : '' }}>
                        {{ $redac->nom_redacteur }}
                    </option>
                @endforeach
            </select>
        </div>
    </div>
</div>
          <div class="row">
            <div class="col-md-6">
              <!-- text input -->
              <div id="divrubprincipal" class="form-group">
                <label for="rubprinarticle">Rubrique Principal &nbsp;<span style="color: red">*</span>&nbsp;: </label>
                <select id="rubprinarticle" type="text" class="form-control border-radius-0" name="post_prinrub" placeholder="" required="required" >
                  <option value="0"><-- Choix rubrique --></option>
                  @foreach($hallrbprins as $prin)
                    @if($prin->id_prinrub!=7)
                    <option class="style-option-principalrub " value="{{$prin->id_prinrub}}" <?=($hupart[0]->prinrubid_article==$prin->id_prinrub)?"selected='selected'":false;?>>{{$prin->desig_prinrub}}</option>
                    @endif
                  @endforeach
                </select>
              </div>
            </div>
            <div class="col-md-5" style="display: none;">
              <!-- text input -->
              <div id="divrubsecondaire" class="form-group">
                <label for="rubsecondarticle">Rubrique Sécondaire &nbsp;<span style="color: red">*</span>&nbsp;:</label>
                <select id="rubsecondarticle" type="text" class="form-control border-radius-0" name="post_secondrub" placeholder="" required="required" >
                  <option value="0"><-- Choix Secondaire --></option>
                  @foreach($hallrbsecs as $sec)
                  <option value="{{$sec->id_secondrub}}" class="style-option-secondrub <?=isset($sec->princrub)?'princrub'.$sec->princrub:false;?>"  <?=($hupart[0]->secondrubid_article==$sec->id_secondrub)?"selected='selected'":false;?>>{{$sec->desig_secondrub}}</option>
                  @endforeach
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <!-- text input -->
              <div id="divflashstatut" class="form-group">
                <label for="flashstatut">A la Une &nbsp;<span style="color: red">*</span>&nbsp;:</label>
                <select id="flashstatut" type="text" class="form-control border-radius-0" name="post_fhstatut" placeholder="" required="required">
                  <option value="0"><-- Choix Statut --></option>
                  @foreach($hallusts as $st)
                  <option value="{{$st->id_alustatut}}" class="" <?=(!empty($hupart[0]->alune_article)&&$hupart[0]->alune_article==$st->id_alustatut)||($st->id_alustatut==1)?"selected='selected'":false;?> >{{$st->lib_alustatut}}</option>
                  @endforeach
                </select>
              </div>
            </div>
          </div>
        </div>
        <!--  -->
        
        <!--  -->
        <div class="card-footer">
          <div class="row">
            <div class="col-sm-6">
              <!-- text input -->
              <div class="form-group button float-left" style="width: 100%;">
                <a href="{{url('/adallposts')}}" class="btn btn-default border-radius-0" style="width: 100%;"><i class="fa fa-arrow-left"></i><span class=" d-none d-sm-inline-block">&nbsp;Voir la Liste des actualités</span></a>
              </div>
            </div>
            <div class="col-sm-6">
              <!-- text input -->
              <div class="form-group button float-right" style="width: 100%;">
                <button type="submit" class="btn btn-primary border-radius-0" style="width: 100%; color: #fff;"><span class=" d-none d-sm-inline-block">Modifier&nbsp;</span> <i class="fa fa-edit"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.card-header-->
      <!-- /.card-body -->
    <!-- /.card -->
  </form>
</div>
<!-- /.row -->
@stop