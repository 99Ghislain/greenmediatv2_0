@extends("layouts/appLayout")
@section("layoutContent")
<div class="row">
  <div class="col-12 mb-3">
    <a href="{{route('admins.addpost')}}" class="btn btn-info">
      <span class="d-none d-sm-inline-block">Ajouter&nbsp;&nbsp;</span>
      <i class="fa fa-plus"></i>
    </a>
  </div>
  <div class="col-12">
  <h2 style="text-align: center;">Liste d' Utilisateurs</h2>
    <form method="get" action="{{route('admins.allusers')}}" class="card">
      <div class="card-header">
        <h3 class="card-title">Toutes les Utilisateurs</h3>

        <div class="card-tools">
          <div  class="input-group input-group-m border-radius-0" style="<?=!empty($dsrch)?'width: 100%;':'width: 100%;';?>">
            <input type="text" name="t_search" class="form-control float-right border-radius-0" value="<?=!empty($dsrch)?$dsrch:false;?>" placeholder="Rechercher par Nom">
            <div class="input-group-append border-radius-0">
              <button type="submit" class="btn btn-default border-radius-0"><i class="fas fa-search"></i></button>
              <?php if (!empty($dsrch)): ;?>
              <!-- <div class="input-group"> -->
              <a href="{{route('admins.allusers')}}" class="btn btn-dark border-radius-0">Voir liste  <i class="fas fa-list"></i></a>
              <!-- </div> -->
              <?php endif ;?>
            </div> 
          </div>
        </div>
      </div>
      <!-- /.card-header  route('admins.allusers',['up'=>us->id])-->
      <div class="card-body table-responsive p-0" style="/*max-height: 500px; overflow: auto;*/ ">
        <table class="table table-head-fixed table-condensed table-striped hovered text-nowrap" style="overflow: auto;">
          <thead>
            <tr>
              <th style="width: 5%;">Photo</th>
              <th class="" style="width: 20%;">Nom</th>
              <th style="width: 5%;">Position</th>
              <th colspan="2" style="width: 10%;">Actions</th>
            </tr>
          </thead>
          <tbody>
            @if(isset($hallus)&&!empty($hallus))
                @foreach($hallus as $us)
                <?php $d=route("admins.allusers",['up'=>$us->id]);?>
                <tr >
                  <td style="width: 5%;"><img src="{{url('hphx/img/'.$us->profile_photo_path)}}" style="width: 50%; margin: 0 auto; padding: 0;"></td>
                  <td class="" style="width: 0%;">{{$us->lastename_user}} {{$us->firstname_user}}</td>
                  <td style="width: 5%;"><span type="button" class="btn btn-warning badge pointer-2">{{$us->desig_type_user}}</span></td>
                  <td style="width: 5%;"><a href="<?=(Auth::user()->id==$us->id)?route('admins.allusers',['up'=>$us->id]):'#';?>" class="btn btn-info" style="<?=(Auth::user()->id==$us->id)?false:'background: #f2f2f2;';?>"><span class="d-none d-sm-inline-block">Modifier&nbsp;&nbsp;</span><i class="fa fa-edit"></i></a></td>
                  <td style="width: 5%;"><button type="button" data-toggle="modal" data-target="#supus{{$us->id}}" class="btn btn-danger" style="" <?=(Auth::user()->id==$us->id&&Auth::user()->type_user_id==2)?false:"disabled='disabled'";?>><span class="d-none d-sm-inline-block">Supprimer&nbsp;&nbsp;</span><i class="fa fa-trash"></i></button></td>
                </tr>
                @endforeach
                
              @else
              <tr style="width: 100%;">
                <td colspan="7" style="width: 100%; text-align: center;"><span class="alert alert-danger" >Aucun Utilisateur enregistré pour le moment ... </span></td>
              </tr>
            @endif
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
      <!-- Paginate Block -->
      {{$hallus->links('contents.apps.templates.blockpagination')}}
      <!-- Paginate Block -->
    </form>
    <!-- /.card -->
  </div>
</div>
<!-- /.row -->
@stop